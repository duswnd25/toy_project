# ReportHelper

> 음성인식 기능을 이용한 레포트 작성 보조 프로그램

## 요약

### 개발자

[![GitHub](https://img.shields.io/badge/GitHub-깃허브-blue.svg?style=flat-square)](http://github.com/duswnd25)
[![Porfolio](https://img.shields.io/badge/Portfolio-포트폴리오-blue.svg?style=flat-square)](https://duswnd25.github.io/portfolio/)
[![LinkedIN](https://img.shields.io/badge/LinkedIN-링크드인-blue.svg?style=flat-square)](https://kr.linkedin.com/in/%EC%97%B0%EC%A4%91-%EA%B9%80-172989119)

### 프로젝트 정보

[![Platform](https://img.shields.io/badge/Platform-Android-blue.svg?style=flat-square)](#)
[![Licensepen Source Love](https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square)](https://github.com/ellerbrock/open-source-badge/)

### 빌드상태

[![Dependency Status](https://www.versioneye.com/user/projects/58b42e819ceb4500303f1674/badge.svg?style=flat-square)](https://www.versioneye.com/user/projects/58b42e819ceb4500303f1674)
[![Build Status](https://www.bitrise.io/app/40f2dd5dea030227.svg?token=PZrM4abl9on6zd1LK61Rkw)](https://www.bitrise.io/app/40f2dd5dea030227)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/1ccb97d4cbee45d1ae7804b755446da6)](https://www.codacy.com/app/duswnd25/ReportHelper?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=duswnd25/ReportHelper&amp;utm_campaign=Badge_Grade)

## 기능

#### 지원

- 다음 뉴톤을 이용한 음성인식 및 컴퓨터 전송

#### 미지원 (지원 예정)

- PC 브라우저 구현

## 설치 요구사항

- **Android API Level 15+**

## 설치

> **아직 지원하지 않습니다.**
