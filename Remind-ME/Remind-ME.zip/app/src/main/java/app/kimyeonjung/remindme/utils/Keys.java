package app.kimyeonjung.remindme.utils;

public class Keys {
	public static final String ContactDBName = "ManageList";
	public static final String RecentLogDBName = "ContactLogList";
}
